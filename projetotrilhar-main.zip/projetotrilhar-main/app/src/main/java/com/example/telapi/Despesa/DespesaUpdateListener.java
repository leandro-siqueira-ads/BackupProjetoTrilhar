package com.example.telapi.Despesa;

import java.util.List;

public interface DespesaUpdateListener {
    void onDespesaAtualizada(List<Despesa> despesas);
}
